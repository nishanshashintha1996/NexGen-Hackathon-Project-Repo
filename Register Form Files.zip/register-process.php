<?php
    //print_r($_POST);
    require '../connection.php';
    if (isset($_POST)) {
        $firstname = $conn_hos_db -> real_escape_string($_POST['fname']);
        $lastname = $conn_hos_db -> real_escape_string($_POST['lname']);
        $email = $conn_hos_db -> real_escape_string($_POST['email']);
        $mobile = $conn_hos_db -> real_escape_string($_POST['mobile']);
        $password = $conn_hos_db -> real_escape_string($_POST['password']);
        $cpassword = $conn_hos_db -> real_escape_string($_POST['cpassword']);
        $rem_status = $conn_hos_db -> real_escape_string($_POST['rem_status']);
        
        if (empty($firstname)) {
            header("location:http://covid-19.my-class.xyz/register/?Hrdndbfgc4865cvtcnc=Empf");
        }
        if (empty($lastname)) {
            header("location:http://covid-19.my-class.xyz/register/?Hrdndbfgc4865cvtcnc=Empl");
        }
        if (empty($email)) {
            header("location:http://covid-19.my-class.xyz/register/?Hrdndbfgc4865cvtcnc=Empe");
        }
        if (empty($mobile)) {
            header("location:http://covid-19.my-class.xyz/register/?Hrdndbfgc4865cvtcnc=Empm");
        }
        if (empty($password)) {
            header("location:http://covid-19.my-class.xyz/register/?Hrdndbfgc4865cvtcnc=Empp");
        }
        if (empty($cpassword)) {
            header("location:http://covid-19.my-class.xyz/register/?Hrdndbfgc4865cvtcnc=Empc");
        }
        if (empty($rem_status)) {
            header("location:http://covid-19.my-class.xyz/register/?Hrdndbfgc4865cvtcnc=Empr");
        }
        if($password!=$cpassword){
            header("location:http://covid-19.my-class.xyz/register/?Hrdndbfgc4865cvtcnc=PasMisMat");
        }else{
            $options = [
                'cost' => 12,
            ];
            $enPass = password_hash($password, PASSWORD_BCRYPT, $options);
        }
        // usr_id	fname	lname	email	mobile	password
        
        $sql_check_data = "SELECT * FROM hospital_user_data WHERE email='$email' or mobile='$mobile'";
        $result_check_data = $conn_hos_db->query($sql_check_data);
        if ($result_check_data->num_rows > 0) {
            header("location:http://covid-19.my-class.xyz/register/?Hrdndbfgc4865cvtcnc=AvaiDa");
        }else{
            $sql_insert_data = "INSERT INTO hospital_user_data (fname, lname, email, mobile, password)
                VALUES ('$firstname', '$lastname', '$email', '$mobile', '$enPass')";
            
            if ($conn_hos_db->query($sql_insert_data) === TRUE) {
                header("location:http://covid-19.my-class.xyz/register/?Hrdndbfgc4865cvtcnc=SucAd");
            } else {
                header("location:http://covid-19.my-class.xyz/register/?Hrdndbfgc4865cvtcnc=SysE");
            }
        }
        
    }else{
        header("location:http://covid-19.my-class.xyz/register/?Hrdndbfgc4865cvtcnc=SysE");
    }
    
?>