<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Register</title>

  <!-- Bootstrap core CSS -->
  <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <style>
        #back{
           background-color:white;
           margin:20px;
           border: 1px solid red;
           border-radius: 10px 10px;
           padding:30px;
        }
        #inp{
           padding:20px;
           border: 1px solid #34c0eb;
           border-radius: 10px 10px;
        }
        .sidenav {
          height: 100%;
          width: 0;
          position: fixed;
          z-index: 1;
          top: 0;
          left: 0;
          background-color: #ffffff;
          overflow-x: hidden;
          transition: 0.5s;
          padding-top: 60px;
          text-align:center;
        }
        
        .sidenav a {
          padding: 8px 8px 8px 32px;
          text-decoration: none;
          font-size: 25px;
          color: #818181;
          display: block;
          transition: 0.3s;
        
        }
        
        .sidenav a:hover{
          color: #f1f1f1;
        }
        
        .sidenav .closebtn {
          position: absolute;
          top: 0;
          right: 25px;
          font-size: 36px;
          margin-left: 50px;
        }
        
        @media screen and (max-height: 450px) {
          .sidenav {padding-top: 15px;}
          .sidenav a {font-size: 18px;}
        }
    </style>
    <script src="https://www.google.com/recaptcha/api.js?render=6Ld23PEUAAAAANAvxb6o7mS_LCVHtDaxRt_UE_hb"></script>
    <script>
        function funcDrive(){
            var c =  "<?php echo $_GET['Hrdndbfgc4865cvtcnc'];?>";
            if(c=="SucAd"){
                document.getElementById("back").style.display = "none";
            }
        }
        
    </script>
</head>

<body onload="funcDrive()" style="background-color:#e6ede9;">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-light static-top">
    <div class="container">
      <!--<a class="navbar-brand" href="#">Start Bootstrap</a>-->
      <button style="background-color:#9e9d95;" onclick="openNav()" class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span onclick="openNav()" class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a style="color: Black;font-weight: bold;" class="nav-link" href="http://covid-19.my-class.xyz/">Login / Register
              <span class="sr-only">(current)</span>
            </a>
          </li>
        </ul>
      </div>
        <div id="mySidenav" class="sidenav">
          <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
          <a class="nav-link" href="http://covid-19.my-class.xyz/">Login / Register
              <span class="sr-only">(current)</span>
          </a>
        </div>
    </div>
  </nav>

  <!-- Page Content -->
  <div class="container">
    <div class="row">
        <div class="col-sm-2"></div>
        <div style="margin-top:20px;" class="col-sm-8">
            <?php
                if(isset($_GET)){
                    $v = $_GET['Hrdndbfgc4865cvtcnc'];
                    if($v=="AvaiDa"){
                        ?>
                            <div class="alert alert-danger" role="alert">
                              <h4 class="alert-heading">Oops!</h4>
                              <p>This Email or Mobile number is wrong or used one.</p>
                              <hr>
                              <p class="mb-0">Please check your email address or Mobile number and Re-enter them.</p>
                            </div>
                        <?php
                    }
                    
                    if($v=="SucAd"){
                        ?>
                            <div class="alert alert-success" role="alert">
                              <h4 class="alert-heading">Well done!</h4>
                              <p>Your Account Sccessfully Created.</p>
                              <hr>
                              <p class="mb-0">Please check your email and Confirm Your Account Before login to the Account.</p>
                            </div>
                        <?php
                    }
                }
            ?>
            
        </div>
        <div class="col-sm-2"></div>
    </div>
    <div  class="row">
      <div class="col-sm-3"></div>
      <div id="back" class="col-sm-6">
         <form method="post" action="register-process.php">
             <!--First Name-->
              <div class="form-group">
                <label for="exampleInputEmail1">First Name</label>
                <input name="fname" id="inp" type="text" class="form-control"  aria-describedby="fNameHelp" required>
                <small id="fNameHelp" class="form-text text-muted"></small>
              </div>
              
             <!--Last Name-->
              <div class="form-group">
                <label for="exampleInputEmail1">Last Name</label>
                <input name="lname" id="inp" type="text" class="form-control"  aria-describedby="lNameHelp" required>
                <small id="lNameHelp" class="form-text text-muted"></small>
              </div>
              
             <!--Email-->
              <div class="form-group">
                <label for="exampleInputEmail1">Email</label>
                <input name="email" id="inp" type="email" class="form-control"  aria-describedby="emailHelp" required>
                <small id="emailHelp" class="form-text text-muted">We will never share your email with anyone else</small>
              </div>
              
             <!--Mobile Number-->
              <div class="form-group">
                <label for="exampleInputEmail1">Mobile Number</label>
                <input name="mobile" id="inp" type="text" class="form-control"  aria-describedby="mobileHelp" required>
                <small id="mobileHelp" class="form-text text-muted"></small>
              </div>
              
             <!--Password-->
              <div class="form-group">
                <label for="exampleInputEmail1">Password</label>
                <input name="password" id="inp" type="password" class="form-control"  aria-describedby="passHelp" required>
                <small id="passHelp" class="form-text text-muted">Password should be 8 characters and One or More capital letters</small>
              </div>
              
             <!--Con-Password-->
              <div class="form-group">
                <label for="exampleInputEmail1">Re Enter Password</label>
                <input name="cpassword" id="inp" type="password" class="form-control" required>
              </div>
              
              
              <div class="form-group form-check">
                <input name="rem_status" type="checkbox" class="form-check-input" id="exampleCheck1" required>
                <label class="form-check-label" for="exampleCheck1">Agree to Terms and Conditions</label>
              </div>
              <!--<input type="hidden" id="token" name="token">-->
              <button type="submit" name="login" class="btn btn-primary">Register</button>
            </form>
        </div>
      <div class="col-sm-3"></div>
      <div style="padding:30px;" class="row"></div>
    </div>
    <!-- <footer class="footer">-->
    <!--  <div class="col-sm-12">-->
    <!--    <span class="text-muted">CopyRight</span>-->
    <!--  </div>-->
    <!--</footer>-->
  </div>
 
  <!-- Bootstrap core JavaScript -->
  <script src="../vendor/jquery/jquery.slim.min.js"></script>
  <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script>
    
    function openNav() {
      document.getElementById("mySidenav").style.width = "100%";
    }
    
    function closeNav() {
      document.getElementById("mySidenav").style.width = "0";
    }
    </script>
</body>

</html>
