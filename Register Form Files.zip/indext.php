<!DOCTYPE html>
<html>
<head>
<title>Register</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<style>
body, html {
  height: 100%;
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

* {
  box-sizing: border-box;
  
}

.bg-image {
  /* The image used */
  background-image: url("https://www.verdict.co.uk/wp-content/uploads/2019/02/robotic-grip-robot-human.jpg");
  
  /* Add the blur effect */
  filter: blur(8px);
  -webkit-filter: blur(8px);
  
  /* Full height */
  height: 100%; 
  
  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}

/* Position text in the middle of the page/image */
.bg-text {
  border: 1px solid red;
  border-radius: 50px 20px;
  padding:30px;
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0, 0.4); /* Black w/opacity/see-through */
  color: white;
  font-weight: bold;
  border: 3px solid #f1f1f1;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  z-index: 2;
  width: 80%;
  text-align: center;
}
#inp{
           padding:20px;
           border: 1px solid #34c0eb;
           border-radius: 30px 10px;
        }
        
</style>
</head>
<body>

<div class="bg-image"></div>

<div class="bg-text">
  <h1 style="font-size:50px">Register</h1>
  <form method="post" action="register-process.php">
             <!--First Name-->
              <div class="form-group">
                <label for="exampleInputEmail1">First Name</label>
                <input name="fname" id="inp" type="text" class="form-control"  aria-describedby="fNameHelp" required>
                <small id="fNameHelp" class="form-text text-muted"></small>
              </div>
              
             <!--Last Name-->
              <div class="form-group">
                <label for="exampleInputEmail1">Last Name</label>
                <input name="lname" id="inp" type="text" class="form-control"  aria-describedby="lNameHelp" required>
                <small id="lNameHelp" class="form-text text-muted"></small>
              </div>
              
             <!--Email-->
              <div class="form-group">
                <label for="exampleInputEmail1">Email</label>
                <input name="email" id="inp" type="email" class="form-control"  aria-describedby="emailHelp" required>
                <small id="emailHelp" class="form-text text-muted">We will never share your email with anyone else</small>
              </div>
              
             <!--Mobile Number-->
              <div class="form-group">
                <label for="exampleInputEmail1">Mobile Number</label>
                <input name="mobile" id="inp" type="text" class="form-control"  aria-describedby="mobileHelp" required>
                <small id="mobileHelp" class="form-text text-muted"></small>
              </div>
              
             <!--Password-->
              <div class="form-group">
                <label for="exampleInputEmail1">Password</label>
                <input name="password" id="inp" type="password" class="form-control"  aria-describedby="passHelp" required>
                <small id="passHelp" class="form-text text-muted">Password should be 8 characters and One or More capital letters</small>
              </div>
              
             <!--Con-Password-->
              <div class="form-group">
                <label for="exampleInputEmail1">Re Enter Password</label>
                <input name="cpassword" id="inp" type="password" class="form-control" required>
              </div>
              
              
              <div class="form-group form-check">
                <input name="rem_status" type="checkbox" class="form-check-input" id="exampleCheck1" required>
                <label class="form-check-label" for="exampleCheck1">Agree to Terms and Conditions</label>
              </div>
              <!--<input type="hidden" id="token" name="token">-->
              <button type="submit" name="login" class="btn btn-primary">Register</button>
            </form>
</div>

</body>
</html>
